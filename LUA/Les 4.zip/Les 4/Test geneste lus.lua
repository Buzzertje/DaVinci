for i = 1, 5 do
  for a = 1 , 9 do
    print ("hoi" .. a )
  end
  print("...................");
  end;