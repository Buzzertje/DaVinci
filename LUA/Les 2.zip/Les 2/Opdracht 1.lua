print ("Is het geel?");

Antwoord = io.read();

if (Antwoord == "Ja") then
  
  print("Kun je erop staan?");
  Antwoord = io.read();
  
     if(Antwoord == "Ja") then
       print("Het is een kuikentje");
    
        else
          print("Het is de zon");
  
end;
end;
 
 if(Antwoord == "Nee") then
 
 print("Is het groot?");
 
 Antwoord = io.read();
   if (Antwoord == "Ja") then
     print("Het is een olifant");
     
   else 
     
     print("Het is een muis");
     
     end;
end;
  