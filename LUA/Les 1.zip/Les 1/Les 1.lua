print ("Hello world");
print ("Hoe heet jij?");

Naam = io.read();
print ("Hallo" .. Naam);
  
  